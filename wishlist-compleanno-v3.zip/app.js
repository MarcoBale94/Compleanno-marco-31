// Wishlist Application JavaScript with Automatic Image Extraction

class WishlistApp {
    constructor() {
        this.gifts = [];
        this.categories = [
            {"nome": "Abbigliamento", "icona": "fas fa-tshirt", "colore": "#FF6B6B"},
            {"nome": "Smart House", "icona": "fas fa-home", "colore": "#4ECDC4"},
            {"nome": "Sport", "icona": "fas fa-dumbbell", "colore": "#45B7D1"},
            {"nome": "Esperienze", "icona": "fas fa-plane", "colore": "#96CEB4"},
            {"nome": "Libri", "icona": "fas fa-book", "colore": "#FECA57"},
            {"nome": "Tecnologia", "icona": "fas fa-laptop", "colore": "#A29BFE"},
            {"nome": "Casa e Giardino", "icona": "fas fa-seedling", "colore": "#6C5CE7"},
            {"nome": "Altro", "icona": "fas fa-gift", "colore": "#FD79A8"}
        ];
        
        this.currentFilter = '';
        this.currentSort = 'name';
        this.currentSearch = '';
        this.editingGiftId = null;
        this.isSharedView = false;
        this.imageCache = new Map();
        this.debounceTimer = null;
        this.currentImageUrl = '';
        
        // Image extraction services
        this.imageServices = [
            {
                name: 'jsonlink',
                url: 'https://jsonlink.io/api/extract?url=',
                parser: this.parseJsonLinkResponse.bind(this)
            },
            {
                name: 'microlink',
                url: 'https://api.microlink.io/?url=',
                parser: this.parseMicrolinkResponse.bind(this)
            }
        ];
        
        this.init();
    }

    init() {
        this.checkSharedView();
        this.loadData();
        this.loadImageCache();
        this.setupEventListeners();
        this.populateCategories();
        this.render();
    }

    checkSharedView() {
        const urlParams = new URLSearchParams(window.location.search);
        this.isSharedView = urlParams.has('shared');
        
        if (this.isSharedView) {
            this.setupSharedView();
        }
    }

    setupSharedView() {
        // Hide add button and modify interface for shared view
        document.getElementById('addGiftBtn').style.display = 'none';
        document.querySelector('.header__actions').style.display = 'none';
        
        // Change title
        const title = document.querySelector('.header__title h1');
        title.innerHTML = '<i class="fas fa-gifts"></i> Lista regali compleanno Marco +31';
        
        // Add shared view info
        const subtitle = document.querySelector('.header__subtitle');
        subtitle.innerHTML = 'Modalità Condivisione - Puoi riservare regali per Marco';
    }

    loadData() {
        try {
            if (this.isSharedView) {
                // In shared view, try to load from URL hash or use example data
                const hashData = window.location.hash.substring(1);
                if (hashData) {
                    this.gifts = JSON.parse(decodeURIComponent(hashData));
                } else {
                    this.loadExampleData();
                }
            } else {
                // Owner view - load from localStorage
                const savedData = localStorage.getItem('wishlist-gifts-marco');
                if (savedData) {
                    this.gifts = JSON.parse(savedData);
                } else {
                    this.loadExampleData();
                    this.saveData();
                }
            }
        } catch (error) {
            console.error('Error loading data:', error);
            this.loadExampleData();
        }
    }

    loadImageCache() {
        try {
            const cacheData = localStorage.getItem('wishlist-image-cache');
            if (cacheData) {
                const parsedCache = JSON.parse(cacheData);
                this.imageCache = new Map(parsedCache);
            }
        } catch (error) {
            console.error('Error loading image cache:', error);
            this.imageCache = new Map();
        }
    }

    saveImageCache() {
        try {
            const cacheArray = Array.from(this.imageCache.entries());
            localStorage.setItem('wishlist-image-cache', JSON.stringify(cacheArray));
        } catch (error) {
            console.error('Error saving image cache:', error);
        }
    }

    loadExampleData() {
        this.gifts = [
            {
                "id": 1,
                "nome": "Maglietta Smart Home Assistant",
                "descrizione": "Maglietta con logo di Home Assistant per veri appassionati di domotica",
                "prezzo": "25€",
                "categoria": "Abbigliamento",
                "priorita": "media",
                "link": "https://www.redbubble.com/i/t-shirt/Home-Assistant-by-homeassistant/41586615.FB110",
                "immagine": "",
                "riservato": false
            },
            {
                "id": 2,
                "nome": "Philips Hue Starter Kit",
                "descrizione": "Kit di lampadine intelligenti per iniziare con l'illuminazione smart",
                "prezzo": "99€",
                "categoria": "Smart House",
                "priorita": "alta",
                "link": "https://www.amazon.it/dp/B016H0QN7E",
                "immagine": "",
                "riservato": false
            },
            {
                "id": 3,
                "nome": "Xiaomi Mi Band 8",
                "descrizione": "Smartwatch per il fitness e monitoraggio attività",
                "prezzo": "45€",
                "categoria": "Sport",
                "priorita": "alta",
                "link": "https://www.mi.com/it/mi-smart-band-8/",
                "immagine": "",
                "riservato": false
            },
            {
                "id": 4,
                "nome": "Cena in ristorante stellato",
                "descrizione": "Esperienza gastronomica in un ristorante di alto livello",
                "prezzo": "150€",
                "categoria": "Esperienze",
                "priorita": "bassa",
                "link": "",
                "immagine": "",
                "riservato": false
            }
        ];
    }

    saveData() {
        if (!this.isSharedView) {
            localStorage.setItem('wishlist-gifts-marco', JSON.stringify(this.gifts));
        }
    }

    setupEventListeners() {
        // Add gift button
        document.getElementById('addGiftBtn')?.addEventListener('click', () => this.openGiftModal());
        
        // Modal events
        document.getElementById('closeModal')?.addEventListener('click', () => this.closeGiftModal());
        document.getElementById('cancelBtn')?.addEventListener('click', () => this.closeGiftModal());
        document.querySelector('.modal__backdrop')?.addEventListener('click', () => this.closeGiftModal());
        
        // Form submission
        document.getElementById('giftForm')?.addEventListener('submit', (e) => this.handleGiftSubmit(e));
        
        // Priority buttons
        document.querySelectorAll('.priority-btn').forEach(btn => {
            btn.addEventListener('click', () => this.selectPriority(btn));
        });
        
        // Link input with debounced image extraction
        document.getElementById('giftLink')?.addEventListener('input', (e) => this.handleLinkInput(e));
        
        // Retry button for image extraction
        document.getElementById('linkRetry')?.addEventListener('click', () => this.retryImageExtraction());
        
        // Search and filters
        document.getElementById('searchInput')?.addEventListener('input', (e) => this.handleSearch(e));
        document.getElementById('categoryFilter')?.addEventListener('change', (e) => this.handleCategoryFilter(e));
        document.getElementById('sortBy')?.addEventListener('change', (e) => this.handleSort(e));
        
        // Share functionality
        document.getElementById('shareBtn')?.addEventListener('click', () => this.openShareModal());
        document.getElementById('copyLinkBtn')?.addEventListener('click', () => this.copyShareLink());
        
        // Theme toggle
        document.getElementById('themeToggle')?.addEventListener('click', () => this.toggleTheme());
        
        // Close modals with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    handleLinkInput(e) {
        const url = e.target.value.trim();
        
        // Clear existing timer
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
        
        // Hide all preview states
        this.hideImagePreview();
        
        if (!url || !this.isValidUrl(url)) {
            return;
        }
        
        // Debounce the image extraction
        this.debounceTimer = setTimeout(() => {
            this.extractImageFromUrl(url);
        }, 800);
    }

    isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch {
            return false;
        }
    }

    async extractImageFromUrl(url) {
        // Check cache first
        if (this.imageCache.has(url)) {
            const cachedImage = this.imageCache.get(url);
            this.showImagePreview(cachedImage, true);
            this.currentImageUrl = cachedImage;
            return;
        }
        
        // Show loading state
        this.showLoadingState();
        
        // Try each service
        for (const service of this.imageServices) {
            try {
                const imageUrl = await this.tryImageService(service, url);
                if (imageUrl) {
                    // Cache the result
                    this.imageCache.set(url, imageUrl);
                    this.saveImageCache();
                    
                    this.showImagePreview(imageUrl, false);
                    this.currentImageUrl = imageUrl;
                    return;
                }
            } catch (error) {
                console.warn(`Service ${service.name} failed:`, error);
            }
        }
        
        // All services failed
        this.showImagePlaceholder();
        this.currentImageUrl = '';
    }

    async tryImageService(service, url) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);
        
        try {
            const response = await fetch(service.url + encodeURIComponent(url), {
                signal: controller.signal,
                headers: {
                    'Accept': 'application/json',
                }
            });
            
            clearTimeout(timeoutId);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const data = await response.json();
            return service.parser(data);
            
        } catch (error) {
            clearTimeout(timeoutId);
            throw error;
        }
    }

    parseJsonLinkResponse(data) {
        if (data && data.images && data.images.length > 0) {
            return data.images[0];
        }
        if (data && data.image) {
            return data.image;
        }
        return null;
    }

    parseMicrolinkResponse(data) {
        if (data && data.data && data.data.image && data.data.image.url) {
            return data.data.image.url;
        }
        return null;
    }

    showLoadingState() {
        document.getElementById('linkLoading').classList.remove('hidden');
        document.getElementById('linkRetry').classList.add('hidden');
        document.getElementById('imagePreview').classList.add('hidden');
        document.getElementById('imagePlaceholder').classList.add('hidden');
    }

    showImagePreview(imageUrl, fromCache) {
        const previewImg = document.getElementById('previewImage');
        const previewStatus = document.getElementById('previewStatus');
        
        previewImg.src = imageUrl;
        previewImg.onload = () => {
            document.getElementById('linkLoading').classList.add('hidden');
            document.getElementById('linkRetry').classList.remove('hidden');
            document.getElementById('imagePreview').classList.remove('hidden');
            document.getElementById('imagePlaceholder').classList.add('hidden');
            
            if (fromCache) {
                previewStatus.innerHTML = '<i class="fas fa-check-circle"></i><span>Immagine dalla cache</span>';
            } else {
                previewStatus.innerHTML = '<i class="fas fa-check-circle"></i><span>Immagine estratta</span>';
            }
        };
        
        previewImg.onerror = () => {
            this.showImagePlaceholder();
        };
    }

    showImagePlaceholder() {
        document.getElementById('linkLoading').classList.add('hidden');
        document.getElementById('linkRetry').classList.remove('hidden');
        document.getElementById('imagePreview').classList.add('hidden');
        document.getElementById('imagePlaceholder').classList.remove('hidden');
    }

    hideImagePreview() {
        document.getElementById('linkLoading').classList.add('hidden');
        document.getElementById('linkRetry').classList.add('hidden');
        document.getElementById('imagePreview').classList.add('hidden');
        document.getElementById('imagePlaceholder').classList.add('hidden');
    }

    retryImageExtraction() {
        const linkInput = document.getElementById('giftLink');
        const url = linkInput.value.trim();
        
        if (url && this.isValidUrl(url)) {
            // Remove from cache to force fresh extraction
            this.imageCache.delete(url);
            this.saveImageCache();
            this.extractImageFromUrl(url);
        }
    }

    populateCategories() {
        const categoryFilter = document.getElementById('categoryFilter');
        const giftCategory = document.getElementById('giftCategory');
        
        if (categoryFilter) {
            this.categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.nome;
                option.textContent = category.nome;
                categoryFilter.appendChild(option);
            });
        }
        
        if (giftCategory) {
            this.categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.nome;
                option.textContent = category.nome;
                giftCategory.appendChild(option);
            });
        }
        
        this.renderCategoryTabs();
    }

    renderCategoryTabs() {
        const tabsContainer = document.getElementById('categoryTabs');
        if (!tabsContainer) return;
        
        // Clear existing tabs except "Tutte"
        const allTab = tabsContainer.querySelector('[data-category=""]');
        tabsContainer.innerHTML = '';
        tabsContainer.appendChild(allTab);
        
        // Add category tabs
        this.categories.forEach(category => {
            const count = this.gifts.filter(gift => gift.categoria === category.nome).length;
            if (count > 0) {
                const tab = document.createElement('button');
                tab.className = 'category-tab';
                tab.dataset.category = category.nome;
                tab.innerHTML = `
                    <i class="${category.icona}"></i>
                    <span>${category.nome}</span>
                    <span class="category-tab__count">${count}</span>
                `;
                tab.addEventListener('click', () => this.selectCategory(category.nome));
                tabsContainer.appendChild(tab);
            }
        });
        
        // Update counts
        this.updateCategoryCounts();
    }

    updateCategoryCounts() {
        const allCount = document.getElementById('allCount');
        if (allCount) {
            allCount.textContent = this.gifts.length;
        }
        
        this.categories.forEach(category => {
            const tab = document.querySelector(`[data-category="${category.nome}"] .category-tab__count`);
            if (tab) {
                const count = this.gifts.filter(gift => gift.categoria === category.nome).length;
                tab.textContent = count;
            }
        });
    }

    selectCategory(category) {
        this.currentFilter = category;
        
        // Update active tab
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.category === category);
        });
        
        // Update filter dropdown
        const filterDropdown = document.getElementById('categoryFilter');
        if (filterDropdown) {
            filterDropdown.value = category;
        }
        
        this.render();
    }

    handleSearch(e) {
        this.currentSearch = e.target.value.toLowerCase();
        this.render();
    }

    handleCategoryFilter(e) {
        this.selectCategory(e.target.value);
    }

    handleSort(e) {
        this.currentSort = e.target.value;
        this.render();
    }

    openGiftModal(giftId = null) {
        this.editingGiftId = giftId;
        const modal = document.getElementById('giftModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('giftForm');
        
        if (giftId) {
            title.textContent = 'Modifica Regalo';
            const gift = this.gifts.find(g => g.id === giftId);
            this.populateGiftForm(gift);
        } else {
            title.textContent = 'Aggiungi Nuovo Regalo';
            form.reset();
            this.selectPriority(document.querySelector('[data-priority="media"]'));
            this.hideImagePreview();
            this.currentImageUrl = '';
        }
        
        modal.classList.remove('hidden');
    }

    populateGiftForm(gift) {
        document.getElementById('giftName').value = gift.nome;
        document.getElementById('giftDescription').value = gift.descrizione || '';
        document.getElementById('giftPrice').value = gift.prezzo || '';
        document.getElementById('giftCategory').value = gift.categoria;
        document.getElementById('giftLink').value = gift.link || '';
        
        const priorityBtn = document.querySelector(`[data-priority="${gift.priorita}"]`);
        this.selectPriority(priorityBtn);
        
        // Show existing image if available
        if (gift.immagine) {
            this.currentImageUrl = gift.immagine;
            this.showImagePreview(gift.immagine, true);
        } else {
            this.hideImagePreview();
            this.currentImageUrl = '';
        }
    }

    closeGiftModal() {
        document.getElementById('giftModal').classList.add('hidden');
        this.editingGiftId = null;
        this.hideImagePreview();
        this.currentImageUrl = '';
        
        // Clear debounce timer
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
    }

    selectPriority(button) {
        document.querySelectorAll('.priority-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        button.classList.add('active');
    }

    handleGiftSubmit(e) {
        e.preventDefault();
        
        const activePriorityBtn = document.querySelector('.priority-btn.active');
        
        const giftData = {
            nome: document.getElementById('giftName').value.trim(),
            descrizione: document.getElementById('giftDescription').value.trim(),
            prezzo: document.getElementById('giftPrice').value.trim(),
            categoria: document.getElementById('giftCategory').value,
            link: document.getElementById('giftLink').value.trim(),
            priorita: activePriorityBtn?.dataset.priority || 'media',
            immagine: this.currentImageUrl || '',
            riservato: false
        };
        
        if (!giftData.nome || !giftData.categoria) {
            this.showToast('Compila tutti i campi obbligatori', 'error');
            return;
        }
        
        if (this.editingGiftId) {
            // Edit existing gift
            const index = this.gifts.findIndex(g => g.id === this.editingGiftId);
            if (index !== -1) {
                this.gifts[index] = { ...this.gifts[index], ...giftData };
                this.showToast('Regalo modificato con successo!', 'success');
            }
        } else {
            // Add new gift
            giftData.id = Date.now();
            this.gifts.push(giftData);
            this.showToast('Regalo aggiunto con successo!', 'success');
        }
        
        this.saveData();
        this.closeGiftModal();
        this.render();
    }

    deleteGift(giftId) {
        if (confirm('Sei sicuro di voler eliminare questo regalo?')) {
            this.gifts = this.gifts.filter(g => g.id !== giftId);
            this.saveData();
            this.render();
            this.showToast('Regalo eliminato', 'info');
        }
    }

    reserveGift(giftId) {
        const gift = this.gifts.find(g => g.id === giftId);
        if (gift && !gift.riservato) {
            gift.riservato = true;
            
            if (this.isSharedView) {
                // In shared view, we can't save to localStorage, but we can update the current view
                this.render();
                this.showToast('Regalo riservato!', 'success');
            } else {
                this.saveData();
                this.render();
                this.showToast('Regalo riservato!', 'success');
            }
        }
    }

    getFilteredAndSortedGifts() {
        let filtered = this.gifts;
        
        // Apply category filter
        if (this.currentFilter) {
            filtered = filtered.filter(gift => gift.categoria === this.currentFilter);
        }
        
        // Apply search filter
        if (this.currentSearch) {
            filtered = filtered.filter(gift =>
                gift.nome.toLowerCase().includes(this.currentSearch) ||
                gift.descrizione.toLowerCase().includes(this.currentSearch) ||
                gift.categoria.toLowerCase().includes(this.currentSearch)
            );
        }
        
        // Apply sorting
        filtered.sort((a, b) => {
            switch (this.currentSort) {
                case 'name':
                    return a.nome.localeCompare(b.nome);
                case 'price':
                    const priceA = parseFloat(a.prezzo?.replace(/[€,]/g, '') || 0);
                    const priceB = parseFloat(b.prezzo?.replace(/[€,]/g, '') || 0);
                    return priceB - priceA;
                case 'priority':
                    const priorityOrder = { 'alta': 3, 'media': 2, 'bassa': 1 };
                    return priorityOrder[b.priorita] - priorityOrder[a.priorita];
                case 'category':
                    return a.categoria.localeCompare(b.categoria);
                default:
                    return 0;
            }
        });
        
        return filtered;
    }

    renderGifts() {
        const giftsContainer = document.getElementById('giftsGrid');
        const emptyState = document.getElementById('emptyState');
        const filteredGifts = this.getFilteredAndSortedGifts();
        
        if (filteredGifts.length === 0) {
            giftsContainer.innerHTML = '';
            emptyState.classList.remove('hidden');
            return;
        }
        
        emptyState.classList.add('hidden');
        
        giftsContainer.innerHTML = filteredGifts.map(gift => {
            const category = this.categories.find(c => c.nome === gift.categoria);
            const categoryColor = category?.colore || '#666';
            const categoryIcon = category?.icona || 'fas fa-gift';
            
            // Image section
            const imageSection = gift.immagine ? 
                `<div class="gift-card__image">
                    <img src="${gift.immagine}" alt="${gift.nome}" loading="lazy">
                </div>` :
                `<div class="gift-card__image">
                    <div class="gift-card__image-placeholder">
                        <i class="fas fa-image"></i>
                        <span>Nessuna immagine</span>
                    </div>
                </div>`;
            
            return `
                <div class="gift-card ${gift.riservato ? 'gift-card--reserved' : ''}">
                    ${gift.riservato ? '<div class="gift-card__reserved-badge"><i class="fas fa-check"></i> Riservato</div>' : ''}
                    
                    ${imageSection}
                    
                    <div class="gift-card__header">
                        <div class="gift-card__category" style="background-color: ${categoryColor}">
                            <i class="${categoryIcon}"></i>
                            <span>${gift.categoria}</span>
                        </div>
                        
                        ${!this.isSharedView ? `
                        <div class="gift-card__actions">
                            <button class="gift-card__action" onclick="app.openGiftModal(${gift.id})" title="Modifica">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="gift-card__action" onclick="app.deleteGift(${gift.id})" title="Elimina">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        ` : ''}
                    </div>
                    
                    <div class="gift-card__body">
                        <h3 class="gift-card__title">${gift.nome}</h3>
                        ${gift.descrizione ? `<p class="gift-card__description">${gift.descrizione}</p>` : ''}
                        
                        <div class="gift-card__footer">
                            ${gift.prezzo ? `<div class="gift-card__price">${gift.prezzo}</div>` : ''}
                            <div class="gift-card__priority gift-card__priority--${gift.priorita}">
                                <i class="fas fa-circle"></i>
                                ${gift.priorita}
                            </div>
                        </div>
                        
                        ${gift.link ? `
                        <div class="gift-card__link">
                            <a href="${gift.link}" target="_blank">
                                <i class="fas fa-external-link-alt"></i>
                                Visualizza prodotto
                            </a>
                        </div>
                        ` : ''}
                        
                        ${this.isSharedView && !gift.riservato ? `
                        <div style="margin-top: var(--space-12);">
                            <button class="btn btn--reserve btn--full-width" onclick="app.reserveGift(${gift.id})">
                                <i class="fas fa-heart"></i> Riserva questo regalo
                            </button>
                        </div>
                        ` : ''}
                        
                        ${this.isSharedView && gift.riservato ? `
                        <div style="margin-top: var(--space-12);">
                            <button class="btn btn--reserved btn--full-width" disabled>
                                <i class="fas fa-check"></i> Già riservato
                            </button>
                        </div>
                        ` : ''}
                    </div>
                </div>
            `;
        }).join('');
    }

    updateStats() {
        const totalGifts = this.gifts.length;
        const reservedGifts = this.gifts.filter(g => g.riservato).length;
        const totalValue = this.gifts.reduce((sum, gift) => {
            const price = parseFloat(gift.prezzo?.replace(/[€,]/g, '') || 0);
            return sum + price;
        }, 0);
        const categoriesUsed = new Set(this.gifts.map(g => g.categoria)).size;
        
        document.getElementById('totalGifts').textContent = totalGifts;
        document.getElementById('reservedGifts').textContent = reservedGifts;
        document.getElementById('totalValue').textContent = `${totalValue.toFixed(0)}€`;
        document.getElementById('categoriesCount').textContent = categoriesUsed;
        
        // Update progress bar
        const progressPercentage = totalGifts > 0 ? (reservedGifts / totalGifts) * 100 : 0;
        document.getElementById('progressFill').style.width = `${progressPercentage}%`;
        document.getElementById('progressText').textContent = `${Math.round(progressPercentage)}% completato`;
    }

    render() {
        this.renderGifts();
        this.updateStats();
        this.renderCategoryTabs();
        this.updateCategoryCounts();
    }

    openShareModal() {
        const modal = document.getElementById('shareModal');
        const shareLink = document.getElementById('shareLink');
        
        // Create share URL with data
        const dataString = encodeURIComponent(JSON.stringify(this.gifts));
        const baseUrl = window.location.origin + window.location.pathname;
        const shareUrl = `${baseUrl}?shared=true#${dataString}`;
        
        shareLink.value = shareUrl;
        modal.classList.remove('hidden');
    }

    closeShareModal() {
        document.getElementById('shareModal').classList.add('hidden');
    }

    copyShareLink() {
        const shareLink = document.getElementById('shareLink');
        shareLink.select();
        document.execCommand('copy');
        this.showToast('Link copiato negli appunti!', 'success');
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-color-scheme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-color-scheme', newTheme);
        localStorage.setItem('theme-preference', newTheme);
        
        const themeIcon = document.querySelector('#themeToggle i');
        themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }

    loadThemePreference() {
        const savedTheme = localStorage.getItem('theme-preference');
        const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        const theme = savedTheme || systemTheme;
        
        document.documentElement.setAttribute('data-color-scheme', theme);
        
        const themeIcon = document.querySelector('#themeToggle i');
        if (themeIcon) {
            themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
        this.editingGiftId = null;
    }

    showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        const icon = toast.querySelector('.toast__icon');
        const messageEl = toast.querySelector('.toast__message');
        
        // Set icon based on type
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            info: 'fas fa-info-circle'
        };
        
        icon.className = `toast__icon ${icons[type] || icons.info}`;
        messageEl.textContent = message;
        
        // Remove existing type classes and add new one
        toast.classList.remove('toast--success', 'toast--error', 'toast--info');
        toast.classList.add(`toast--${type}`);
        
        // Show toast
        toast.classList.remove('hidden');
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            toast.classList.add('hidden');
        }, 3000);
    }
}

// Initialize the application
const app = new WishlistApp();

// Load theme preference on startup
document.addEventListener('DOMContentLoaded', () => {
    app.loadThemePreference();
});

// Handle clicks on modal backdrop
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal__backdrop')) {
        app.closeAllModals();
    }
});

// Handle share modal close
function closeShareModal() {
    app.closeShareModal();
}

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WishlistApp;
}